from flask import Flask, render_template, request, redirect, session, flash, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import os

app = Flask(__name__)

# ---------------- CONFIG ----------------
app.secret_key = 'your_secret_key_here'

# MySQL connection
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Narean%4025@localhost/blog_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

db = SQLAlchemy(app)

# ---------------- MODELS ----------------
class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    profile_pic = db.Column(db.String(100), nullable=True)
    posts = db.relationship('Post', backref='user', cascade="all, delete-orphan", lazy=True)
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)
    notifications = db.relationship('Notification', backref='user', lazy=True)

class Post(db.Model):
    __tablename__ = 'posts'
    post_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    image = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    comments = db.relationship('Comment', backref='post', cascade="all, delete-orphan", lazy=True)
    likes = db.relationship('Like', backref='post', cascade="all, delete-orphan", lazy=True)

class Comment(db.Model):
    __tablename__ = 'comments'
    comment_id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('posts.post_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    comment = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Like(db.Model):
    __tablename__ = 'likes'
    like_id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('posts.post_id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Message(db.Model):
    __tablename__ = 'messages'
    message_id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

class Notification(db.Model):
    __tablename__ = 'notifications'
    notification_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    content = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    reference_id = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

# ---------------- CREATE TABLES ----------------
def init_db():
    """Initialize the database by creating all tables if they don't exist"""
    with app.app_context():
        try:
            # Create all tables if they don't exist
            db.create_all()
            print("✓ Database tables created successfully")
            
            # Check if we need to create a test user
            if not User.query.first():
                test_user = User(
                    username='testuser',
                    password=generate_password_hash('testpassword'),
                    email='test@example.com',
                    bio='This is a test user bio'
                )
                db.session.add(test_user)
                db.session.commit()
                print("✓ Test user created (username: testuser, password: testpassword)")
            else:
                print("✓ Database already has users")
                
        except Exception as e:
            print(f"✗ Error initializing database: {e}")
            db.session.rollback()

# Initialize the database when the app starts
print("Initializing database...")
init_db()

# ---------------- HELPERS ----------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for('login'))
        
        # Verify the user still exists in the database
        current_user = User.query.filter_by(username=session['user']).first()
        if not current_user:
            session.pop('user', None)
            flash("Your session has expired. Please log in again.", "warning")
            return redirect(url_for('login'))
            
        return f(*args, **kwargs)
    return decorated_function

def get_current_user():
    """Helper function to get current user with error handling"""
    if 'user' not in session:
        return None
    return User.query.filter_by(username=session['user']).first()

# ---------------- ROUTES ----------------

# ---------- Register ----------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user' in session:
        return redirect('/')
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash("Username already exists!", "warning")
            return redirect('/register')

        hashed_pw = generate_password_hash(password)
        new_user = User(username=username, password=hashed_pw)
        db.session.add(new_user)
        db.session.commit()
        flash("Registration successful! Please log in.", "success")
        return redirect('/login')
    return render_template('register.html')

# ---------- Login ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user' in session:
        return redirect('/')
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user'] = user.username
            flash(f"Welcome, {user.username}!", "success")
            return redirect('/')
        else:
            flash("Invalid username or password", "danger")
    return render_template('login.html')

# ---------- Logout ----------
@app.route('/logout')
@login_required
def logout():
    session.pop('user', None)
    flash("You have logged out.", "info")
    return redirect('/login')

# ---------- Home ----------
@app.route('/')
@login_required
def index():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
    
    posts = Post.query.order_by(Post.created_at.desc()).all()

    for post in posts:
        post.is_liked = Like.query.filter_by(user_id=current_user.user_id, post_id=post.post_id).first() is not None

    unread_messages = Message.query.filter_by(receiver_id=current_user.user_id, is_read=False).count()
    unread_notifications = Notification.query.filter_by(user_id=current_user.user_id, is_read=False).count()

    return render_template('index.html', posts=posts, unread_messages=unread_messages, unread_notifications=unread_notifications)

# ---------- My Posts ----------
@app.route('/my_posts')
@login_required
def my_posts():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
    
    # Get only the current user's posts, ordered by most recent first
    user_posts = Post.query.filter_by(user_id=current_user.user_id).order_by(Post.created_at.desc()).all()
    
    # Count likes and comments for each post
    for post in user_posts:
        post.likes_count = Like.query.filter_by(post_id=post.post_id).count()
        post.comments_count = Comment.query.filter_by(post_id=post.post_id).count()
    
    unread_messages = Message.query.filter_by(receiver_id=current_user.user_id, is_read=False).count()
    unread_notifications = Notification.query.filter_by(user_id=current_user.user_id, is_read=False).count()
    
    return render_template('my_posts.html', 
                         posts=user_posts, 
                         unread_messages=unread_messages, 
                         unread_notifications=unread_notifications)

# ---------- Add Post ----------
@app.route('/add_post', methods=['GET', 'POST'])
@login_required
def add_post():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        image_file = request.files.get('image')
        image_filename = None

        if image_file and allowed_file(image_file.filename):
            image_filename = secure_filename(image_file.filename)
            image_file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))

        new_post = Post(title=title, content=content, user_id=current_user.user_id, image=image_filename)
        db.session.add(new_post)
        db.session.commit()
        flash("Post added successfully!", "success")
        return redirect('/')
    return render_template('add_post.html')

# ---------- View Post ----------
@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
@login_required
def post_view(post_id):
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    post = Post.query.get_or_404(post_id)

    if request.method == 'POST':
        comment_text = request.form['comment']
        new_comment = Comment(post_id=post.post_id, name=current_user.username, comment=comment_text)
        db.session.add(new_comment)

        if current_user.user_id != post.user_id:
            notification = Notification(user_id=post.user_id,
                                        content=f"{current_user.username} commented on your post: {post.title[:30]}...",
                                        type='comment',
                                        reference_id=post_id)
            db.session.add(notification)

        db.session.commit()
        flash("Comment added!", "success")
        return redirect(f'/post/{post_id}')

    comments = Comment.query.filter_by(post_id=post_id).order_by(Comment.created_at.desc()).all()
    return render_template('post.html', post=post, comments=comments)

# ---------- Delete Post ----------
@app.route('/delete_post/<int:post_id>')
@login_required
def delete_post(post_id):
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    post = Post.query.get_or_404(post_id)

    if post.user_id != current_user.user_id:
        flash("You can only delete your own posts.", "danger")
        return redirect('/')

    # Delete associated notifications for this post
    Notification.query.filter_by(reference_id=post_id).delete()
    
    db.session.delete(post)
    db.session.commit()
    flash("Post deleted successfully.", "info")
    return redirect('/my_posts')

# ---------- Toggle Like ----------
@app.route('/toggle_like/<int:post_id>', methods=['POST'])
@login_required
def toggle_like(post_id):
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    post = Post.query.get_or_404(post_id)

    existing_like = Like.query.filter_by(user_id=current_user.user_id, post_id=post_id).first()

    if existing_like:
        db.session.delete(existing_like)
        # Remove like notification if exists
        Notification.query.filter_by(
            user_id=post.user_id,
            type='like',
            reference_id=post_id
        ).delete()
    else:
        new_like = Like(user_id=current_user.user_id, post_id=post_id)
        db.session.add(new_like)
        if current_user.user_id != post.user_id:
            notification = Notification(user_id=post.user_id,
                                        content=f"{current_user.username} liked your post: {post.title[:30]}...",
                                        type='like',
                                        reference_id=post_id)
            db.session.add(notification)

    db.session.commit()
    return redirect(request.referrer or url_for('index'))

# ---------- Messages ----------
@app.route('/messages')
@login_required
def messages():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    messages = Message.query.filter(
        (Message.sender_id == current_user.user_id) | (Message.receiver_id == current_user.user_id)
    ).order_by(Message.created_at.desc()).all()
    
    # Mark messages as read when user views them
    unread_messages = Message.query.filter_by(receiver_id=current_user.user_id, is_read=False).all()
    for msg in unread_messages:
        msg.is_read = True
    db.session.commit()
    
    return render_template('messages.html', messages=messages, current_user=current_user)

# ---------- Compose Message ----------
@app.route('/compose_message', methods=['GET', 'POST'])
@login_required
def compose_message():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    users = User.query.filter(User.user_id != current_user.user_id).all()

    if request.method == 'POST':
        receiver_id = request.form['receiver_id']
        content = request.form['content']

        new_message = Message(sender_id=current_user.user_id,
                              receiver_id=receiver_id,
                              content=content)
        db.session.add(new_message)
        
        # Create notification for the receiver
        notification = Notification(
            user_id=receiver_id,
            content=f"{current_user.username} sent you a message",
            type='message',
            reference_id=current_user.user_id
        )
        db.session.add(notification)
        
        db.session.commit()
        flash("Message sent successfully!", "success")
        return redirect(url_for('messages'))

    return render_template('compose_message.html', users=users, current_user=current_user)

# ---------- Reply Message ----------
@app.route('/reply/<int:receiver_id>', methods=['GET', 'POST'])
@login_required
def reply_message(receiver_id):
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    receiver = User.query.get_or_404(receiver_id)

    if request.method == 'POST':
        content = request.form['content']
        new_message = Message(sender_id=current_user.user_id,
                              receiver_id=receiver.user_id,
                              content=content)
        db.session.add(new_message)
        
        # Create notification for the receiver
        notification = Notification(
            user_id=receiver.user_id,
            content=f"{current_user.username} sent you a message",
            type='message',
            reference_id=current_user.user_id
        )
        db.session.add(notification)
        
        db.session.commit()
        flash("Reply sent successfully!", "success")
        return redirect(url_for('messages'))

    return render_template('reply_message.html', receiver=receiver, current_user=current_user)

# ---------- NOTIFICATIONS ROUTES ----------

# ---------- View Notifications ----------
@app.route('/notifications')
@login_required
def notifications():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    user_notifications = Notification.query.filter_by(user_id=current_user.user_id).order_by(Notification.created_at.desc()).all()
    
    # Mark notifications as read when user views them
    for notification in user_notifications:
        if not notification.is_read:
            notification.is_read = True
    db.session.commit()
    
    unread_messages = Message.query.filter_by(receiver_id=current_user.user_id, is_read=False).count()
    unread_notifications = 0  # All will be read after this page loads
    
    return render_template('notifications.html', 
                         notifications=user_notifications,
                         unread_messages=unread_messages,
                         unread_notifications=unread_notifications)

# ---------- Mark Single Notification as Read ----------
@app.route('/notifications/mark_read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    current_user = get_current_user()
    if not current_user:
        return jsonify({'success': False, 'error': 'User not found'}), 401
        
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.user_id != current_user.user_id:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 403
    
    notification.is_read = True
    db.session.commit()
    
    return jsonify({'success': True})

# ---------- Clear All Notifications ----------
@app.route('/clear_notifications', methods=['POST'])
@login_required
def clear_notifications():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
    
    try:
        # Delete all notifications for the current user
        Notification.query.filter_by(user_id=current_user.user_id).delete()
        db.session.commit()
        flash("All notifications cleared.", "success")
    except Exception as e:
        flash("Error clearing notifications.", "danger")
    
    return redirect(url_for('notifications'))

# ---------- Get Unread Notifications Count (for AJAX) ----------
@app.route('/notifications/unread_count')
@login_required
def unread_notifications_count():
    current_user = get_current_user()
    if not current_user:
        return jsonify({'count': 0})
        
    count = Notification.query.filter_by(user_id=current_user.user_id, is_read=False).count()
    return jsonify({'count': count})

# ---------- Delete Single Notification ----------
@app.route('/notifications/delete/<int:notification_id>', methods=['POST'])
@login_required
def delete_notification(notification_id):
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.user_id != current_user.user_id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for('notifications'))
    
    db.session.delete(notification)
    db.session.commit()
    flash("Notification deleted.", "info")
    
    return redirect(url_for('notifications'))

# ---------- User Settings ----------
@app.route('/settings')
@login_required
def settings():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    return render_template('settings.html', user=current_user)

@app.route('/update_settings', methods=['POST'])
@login_required
def update_settings():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    new_username = request.form.get('username')
    email = request.form.get('email')
    bio = request.form.get('bio')

    changes_made = False

    # Update username
    if new_username and new_username != current_user.username:
        if User.query.filter_by(username=new_username).first():
            flash("Username already taken!", "warning")
            return redirect(url_for('settings'))
        current_user.username = new_username
        session['user'] = new_username
        changes_made = True

    # Update email
    if email != current_user.email:
        current_user.email = email
        changes_made = True

    # Update bio
    if bio != current_user.bio:
        current_user.bio = bio
        changes_made = True

    if changes_made:
        db.session.commit()
        flash("Profile updated successfully!", "success")
    else:
        flash("No changes made.", "info")

    return redirect(url_for('settings'))

@app.route('/change_password', methods=['POST'])
@login_required
def change_password():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    old_password = request.form.get('old_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')

    if not check_password_hash(current_user.password, old_password):
        flash("Current password is incorrect!", "danger")
        return redirect(url_for('settings'))

    if new_password != confirm_password:
        flash("New passwords do not match!", "warning")
        return redirect(url_for('settings'))

    current_user.password = generate_password_hash(new_password)
    db.session.commit()
    flash("Password changed successfully!", "success")
    return redirect(url_for('settings'))

# ---------- PROFILE PICTURE ROUTES ----------

@app.route('/update_profile_pic', methods=['POST'])
@login_required
def update_profile_pic():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    image_file = request.files.get('profile_pic')

    if image_file and allowed_file(image_file.filename):
        # Delete old profile picture if exists
        if current_user.profile_pic and os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic)):
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic))
            except OSError:
                pass  # File might not exist, continue anyway
        
        # Save new profile picture
        filename = secure_filename(image_file.filename)
        # Add timestamp to make filename unique
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{current_user.user_id}_{timestamp}_{filename}"
        
        image_file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        
        current_user.profile_pic = filename
        db.session.commit()
        flash("Profile picture updated successfully!", "success")
    else:
        flash("Please select a valid image file (PNG, JPG, JPEG, GIF).", "warning")

    return redirect(url_for('settings'))

@app.route('/remove_profile_pic', methods=['POST'])
@login_required
def remove_profile_pic():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    if current_user.profile_pic:
        # Delete the profile picture file
        if os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic)):
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic))
            except OSError:
                pass  # File might not exist, continue anyway
        
        current_user.profile_pic = None
        db.session.commit()
        flash("Profile picture removed successfully!", "success")
    else:
        flash("No profile picture to remove.", "info")
    
    return redirect(url_for('settings'))

# ---------- DELETE ACCOUNT ROUTES ----------

@app.route('/delete_account', methods=['POST'])
@login_required
def delete_account():
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    try:
        # Get user data for confirmation message
        username = current_user.username
        
        # Delete profile picture if exists
        if current_user.profile_pic and os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic)):
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], current_user.profile_pic))
            except OSError:
                pass
        
        # Delete all user-related data
        # 1. Delete user's posts (cascade will handle comments and likes on those posts)
        Post.query.filter_by(user_id=current_user.user_id).delete()
        
        # 2. Delete comments made by the user on other posts
        Comment.query.filter_by(name=current_user.username).delete()
        
        # 3. Delete likes by the user
        Like.query.filter_by(user_id=current_user.user_id).delete()
        
        # 4. Delete messages sent and received by the user
        Message.query.filter(
            (Message.sender_id == current_user.user_id) | 
            (Message.receiver_id == current_user.user_id)
        ).delete()
        
        # 5. Delete notifications for the user
        Notification.query.filter_by(user_id=current_user.user_id).delete()
        
        # 6. Delete notifications that reference the user's posts
        # This handles notifications about the user's posts that were sent to other users
        user_post_ids = [post.post_id for post in Post.query.filter_by(user_id=current_user.user_id).all()]
        if user_post_ids:
            Notification.query.filter(Notification.reference_id.in_(user_post_ids)).delete()
        
        # 7. Finally delete the user
        db.session.delete(current_user)
        db.session.commit()
        
        # Clear session
        session.pop('user', None)
        
        flash(f"Account '{username}' has been permanently deleted. We're sorry to see you go!", "info")
        return redirect(url_for('login'))
        
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while deleting your account. Please try again.", "danger")
        return redirect(url_for('settings'))

@app.route('/confirm_delete', methods=['GET'])
@login_required
def confirm_delete():
    """Route to show confirmation page before account deletion"""
    current_user = get_current_user()
    if not current_user:
        session.pop('user', None)
        flash("Please log in again.", "warning")
        return redirect(url_for('login'))
        
    return render_template('confirm_delete.html', user=current_user)

# ---------------- RUN ----------------
if __name__ == '__main__':
    print("Starting Flask application...")
    app.run(debug=True)
